@extends('layouts.user.app')

@section('content')
<main class="dashboard-mp">
    <div class="dash-todo-thumbnail-area1">
        <div class="todo-thumb1 dash-bg-image1 dash-bg-overlay" style="background-image:url({{ Auth::user()->background() }}?w=1352&h=350);"></div>
        <div class="dash-todo-header1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="my-profile-dash">
                            <div class="my-dp-dash">
                                <img src="{{ Auth::user()->image() }}?w=150&h=150" alt="logo">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="dash-dts">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="event-title">
                        <div class="my-dash-dt">
                            <h3>{{ ucfirst(Auth::user()->first_name) }} {{ ucfirst(Auth::user()->last_name) }} ({{ ucfirst(Auth::user()->user_name) }})</h3>
                            <span>Member since  {{ Auth::user()->created_at->format('F Y') }}</span>
                            <span><i class="fas fa-envelope"></i>{{ Auth::user()->email }}</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <ul class="right-details">
                        <li>
                            <div class="my-all-evnts">
                                <a href="{{ route('user.dashboard') }}">View Events</a>
                            </div>
                        </li>
                        <li>
                            <div class="all-dis-evnt">
                                <div class="dscun-txt">Events</div>
                                <div class="dscun-numbr">22</div>
                            </div>
                        </li>
                        <li>
                            <div class="all-dis-evnt">
                                <div class="dscun-txt">Discussions</div>
                                <div class="dscun-numbr">40</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="dash-tab-links">
        <div class="container">
            <div class="row">
                <!-- <div class="col-lg-12 col-md-12">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" href="{{ route('user.dashboard') }}">Activity</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Discussions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Followers <span class="badge badge-alrts">20</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Following <span class="badge badge-alrts">20</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Messages <span class="badge badge-alrts">2</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Credits</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Booked Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">History</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}">Setting</a>
                        </li>
                    </ul>
                </div> -->
                <div class="setting-page mb-20">
                    <div class="row">
                        <div class="col-lg-3 col-md-5">
                            <div class="user-data full-width">
                                <div class="categories-left-heading">
                                    <h3>Your Details</h3>
                                </div>
                                <div class="categories-items">
                                    <a class="tab-item-1 {{ navbar('user.dashboard') }}" href="{{ route('user.dashboard') }}">Personal Info</a>
                                    <a class="tab-item-1 {{ navbar('user.profile') }}" href="{{ route('user.profile') }}">Profile</a>
                                    <a class="tab-item-1 {{ navbar('user.social') }}" href="{{ route('user.social') }}">Social Networks</a>
                                    <a class="tab-item-1 {{ navbar('user.email') }}" href="{{ route('user.email') }}">Email Setting</a>
                                    <a class="tab-item-1 {{ navbar('user.notification') }}" href="{{ route('user.notification') }}">Notification Setting</a>
                                    <a class="tab-item-1 {{ navbar('user.change_pass') }}" href="{{ route('user.change_pass') }}">Change Password</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-7">
                            @yield('dashboard')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
