@extends('user.dashboard.layouts')
@section('title', 'Change Password')

@section('css')
@endsection

@section('style')
@endsection

@section('dashboard')
<div class="setting-form">
    <div class="user-data full-width">
        <div class="about-left-heading">
            <h3>Change Password</h3>
        </div>
        <div class="prsnl-info">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <form method="POST" action="{{ route('user.change_pass') }}">
                        @csrf
                        <div class="form-group">
                            <label>Old Password*</label>
                            <input class="payment-input" name="old_password" required type="Password" placeholder="Enter Old Password">
                        </div>
                        <div class="form-group">
                            <label>New Password*</label>
                            <input class="payment-input" name="password" required type="Password" placeholder="Enter New Password">
                        </div>
                        <div class="form-group">
                            <label>Confirmed New Password*</label>
                            <input class="payment-input" name="password_confirmation" required type="Password" placeholder="Enter Confirmed New Password">
                        </div>
                        <div class="add-profile-btn">
                            <button class="setting-save-btn" type="submit">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
@endsection
