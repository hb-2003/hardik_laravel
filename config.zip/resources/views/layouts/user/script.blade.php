
@yield('js')
<!-- Jquery Core Js -->
<script src="{{asset('assets/bundles/libscripts.bundle.js')}}"></script>

<!-- Plugin Js-->
<script src="{{asset('assets/bundles/apexcharts.bundle.js')}}"></script>

<!-- Jquery Page Js -->
<script src="{{asset('assets/js/template.js')}}"></script>
<script src="{{asset('assets/js/page/hr.js')}}"></script>
     
