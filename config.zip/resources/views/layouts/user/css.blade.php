
<!-- Plugins css start-->
@yield('css')
<!-- Plugins css Ends-->
@yield('style')

  <link rel="stylesheet" href="{{asset('assets/css/my-task.style.min.css')}}">

    