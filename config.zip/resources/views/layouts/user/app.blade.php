<!doctype html>
<html class="no-js" lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>:: My-Task:: Employee Dashboard </title>
    <link rel="icon" href="{{asset('favicon.ico')}}" type="image/x-icon"> <!-- Favicon-->
    <!-- project css file  -->
    <!-- project css file  -->
   
        @include('layouts.user.css')
    </head>
    <body>
        <!-- Header Start -->
        @include('layouts.user.header')
        <!-- Header End -->
        <!-- Body Start -->
        @yield('content')
        <!-- Body End -->
        <!-- Footer Start -->
        @include('layouts.user.footer')
        <!-- Footer End -->
        <!-- Scripts js Start -->
        @include('layouts.user.script')
        @include('layouts.user.notification')
        <!-- Scripts js End -->
    </body>
</html>
