<!doctype html>
<html lang="en" data-layout="twocolumn" data-sidebar="light" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">

<head>

    <meta charset="utf-8" />
    <title>CRM | Velzon - Admin & Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
        <title>{{ config('app.name', 'Tournament') }} - @yield('title')</title>
        <!-- Stylesheets -->
        @include('layouts.admin.css')
    </head>
    <body>
      
            @include('layouts.admin.header')
            <!-- Page Header Ends                              -->
            <!-- Page Body Start-->
            
                <!-- Page Sidebar Start-->
                @include('layouts.admin.sidebar')
                <!-- Page Sidebar Ends-->
                
                                    
                        @yield('content')
                    </div>
                    <!-- Container-fluid Ends-->
                </div>
                <!-- footer start-->
                @include('layouts.admin.footer')
            </div>
        </div>
        <!-- Scripts js Start -->
        @include('layouts.admin.script')
        @include('layouts.admin.notification')
        <!-- Scripts js End -->
    </body>
</html>
