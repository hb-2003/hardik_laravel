
## Project Installation

composer install

php artisan key:generate

php artisan migrate:refresh --seed

php artisan storage:link

php artisan serve

## Laravel command

php artisan make:model User -m

php artisan make:controller User/HomeController
