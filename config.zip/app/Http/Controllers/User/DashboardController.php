<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

use Illuminate\Support\Facades\Hash;
use URL;
use Str;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $users = User::count();
        $user = auth()->user();
        $referralUrl = URL::to('/').'/register?referralcode='.$user->referralcode;
        return view('user.dashboard.index', ['user' => $user, 'referralUrl' => $referralUrl],compact('users'));
    }

    public function profile(Request $request)
    {
        if ($request->isMethod('POST')) {
            $data = $request->validate([
                'images' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                'backgrounds' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);
            if ($request->hasFile('images')) {
                $image_name = Str::uuid() . '.' . Str::lower($request->images->getClientOriginalExtension());
                $request->images->storeAs('public/users', $image_name);
                $data['image'] = $image_name;
            }
            if ($request->hasFile('backgrounds')) {
                $image_name = Str::uuid() . '.' . Str::lower($request->backgrounds->getClientOriginalExtension());
                $request->backgrounds->storeAs('public/users', $image_name);
                $data['background'] = $image_name;
            }
            $user = auth()->user();
            $user->update($data);
            session()->put('success', 'Your profile image data has been updated.');
            return redirect()->route('user.profile');
        }
        if ($request->isMethod('GET')) {
            return view('user.dashboard.profile');
        }
    }

    public function social(Request $request)
    {
        //  echo "<pre>";
        // print_r('request');
        // die;
        return view('user.dashboard.social');
    }

    public function email(Request $request)
    {
         // echo "<pre>";        
         // print_r($request->all());        
         // die; 
        if ($request->isMethod('POST')) {
            $user = auth()->user();
            $data = $request->validate([
                'old_email' => 'required|string|email|max:255',
                'email' => 'required|string|email|max:255|unique:users,email,' . $user->id . ',id,deleted_at,NULL',
            ]);
            if ($data['old_email'] == $user->email) {
                $user->update($data);
                session()->put('success', 'Your email address has been changed successfully.');
            } else {
                session()->put('error', 'Please enter correct current old email address.');
            }
            return redirect()->route('user.email');
        }
        if ($request->isMethod('GET')) {
            return view('user.dashboard.email');
        }
    }

    public function notification(Request $request)
    {
        return view('user.dashboard.notification');
    }

    public function change_pass(Request $request)
    {
        if ($request->isMethod('POST')) {
            $data = $request->validate([
                'old_password' => 'required|min:8|max:15',
                'password' => 'required|min:8|max:15|confirmed',
            ]);
            $user = auth()->user();
            if (Hash::check($data['old_password'], $user->password)) {
                $user->password = Hash::make($data['password']);
                $user->save();
                session()->put('success', 'Your password has been changed successfully.');
            } else {
                session()->put('error', 'Please enter correct current password.');
            }
            return redirect()->route('user.change_pass');
        }
        if ($request->isMethod('GET')) {
            return view('user.dashboard.change_pass');
        }
    }
}
