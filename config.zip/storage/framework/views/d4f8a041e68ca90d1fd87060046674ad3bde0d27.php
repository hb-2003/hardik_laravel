
<!-- Plugins css start-->
<?php echo $__env->yieldContent('css'); ?>
<!-- Plugins css Ends-->
<?php echo $__env->yieldContent('style'); ?>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/my-task.style.min.css')); ?>">

    <?php /**PATH C:\xampp\htdocs\tournament\resources\views/layouts/user/css.blade.php ENDPATH**/ ?>