
<?php echo $__env->yieldContent('js'); ?>
<!-- Jquery Core Js -->
<script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>

<!-- Plugin Js-->
<script src="<?php echo e(asset('assets/bundles/apexcharts.bundle.js')); ?>"></script>

<!-- Jquery Page Js -->
<script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/hr.js')); ?>"></script>
     
<?php /**PATH C:\xampp\htdocs\tournament\resources\views/layouts/user/script.blade.php ENDPATH**/ ?>