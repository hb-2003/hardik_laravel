<!doctype html>
<html lang="en" data-layout="twocolumn" data-sidebar="light" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">

<head>

    <meta charset="utf-8" />
    <title>CRM | Velzon - Admin & Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
        <title><?php echo e(config('app.name', 'Tournament')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <!-- Stylesheets -->
        <?php echo $__env->make('layouts.admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
      
            <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Page Header Ends                              -->
            <!-- Page Body Start-->
            
                <!-- Page Sidebar Start-->
                <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Page Sidebar Ends-->
                
                                    
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <!-- Container-fluid Ends-->
                </div>
                <!-- footer start-->
                <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- Scripts js Start -->
        <?php echo $__env->make('layouts.admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.admin.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Scripts js End -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tournament\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>