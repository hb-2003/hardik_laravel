<!doctype html>
<html class="no-js" lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>:: My-Task:: Employee Dashboard </title>
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon"> <!-- Favicon-->
    <!-- project css file  -->
    <!-- project css file  -->
   
        <?php echo $__env->make('layouts.user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <!-- Header Start -->
        <?php echo $__env->make('layouts.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header End -->
        <!-- Body Start -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Body End -->
        <!-- Footer Start -->
        <?php echo $__env->make('layouts.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer End -->
        <!-- Scripts js Start -->
        <?php echo $__env->make('layouts.user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.user.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Scripts js End -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tournament\resources\views/layouts/user/app.blade.php ENDPATH**/ ?>