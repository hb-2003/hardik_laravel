<script>
    <?php if(Session::has('success')): ?>
        $.notify({
            icon: 'fa fa-check-circle',
            title: '<strong>Success !</strong>',
            message: "<?php echo e(Session::get('success')); ?>"
        },{
            type: 'success'
        });
        <?php
            Session::forget('success');
        ?>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        $.notify({
            icon: 'fa fa-exclamation-circle',
            title: '<strong>Error !</strong>',
            message: "<?php echo e(Session::get('error')); ?>"
        },{
            type: 'danger'
        });
        <?php
            Session::forget('error');
        ?>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $.notify({
                message: "<?php echo e($error); ?>"
            },{
                type: 'danger'
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\tournament1\resources\views/layouts/admin/notification.blade.php ENDPATH**/ ?>