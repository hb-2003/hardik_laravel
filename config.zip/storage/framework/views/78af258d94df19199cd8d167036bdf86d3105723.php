<!doctype html>

<html lang="en" data-layout="twocolumn" data-sidebar="light" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">

<head>

    <meta charset="utf-8" />
    <title>Login Register Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />

        <title><?php echo e(config('app.name', 'Tournament')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

        <!-- Favicon Icon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('user/images/fav.png')); ?>">

        <!-- Stylesheets -->
       
    </head>
    <body>
      <header>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <nav class="navbar navbar-expand-lg navbar-light bg-dark1 justify-content-sm-start">
                   
                       
                        <?php if(auth()->guard()->check()): ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="add-event">Login</a>
                            <a href="<?php echo e(route('register')); ?>" class="add-event">Register</a>
                        <?php endif; ?>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <div class="account order-1 dropdown">
                        <a href="#" class="account-link dropdown-toggle-no-caret" role="button" data-toggle="dropdown">
                            <div class="user-dp">
                                <img src="<?php echo e(Auth::user()->image()); ?>?w=35&h=35" alt="<?php echo e(Auth::user()->user_name); ?>">
                            </div>
                            <span><?php echo e(ucfirst(Auth::user()->first_name)); ?> <?php echo e(ucfirst(Auth::user()->last_name)); ?></span>
                            <i class="fas fa-angle-down"></i>
                        </a>
                        
                    </div>
                    <?php endif; ?>
                </nav>
                <div class="overlay"></div>
            </div>
        </div>
    </div>
</header>

    </body>
</html>

<?php /**PATH C:\xampp\htdocs\tournament\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>