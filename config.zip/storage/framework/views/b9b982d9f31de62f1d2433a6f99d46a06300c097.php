
<?php $__env->startSection('title', 'Password Reset'); ?>
<?php $__env->startSection('content'); ?>
    <p>you forgot your password for Cuba Admin. If this is true, click below to reset your password.</p>
    <p style="text-align: center">
        <a href="<?php echo e(route('password.reset', ['token' => $token, 'email' => $user['email']])); ?>" style="padding: 10px; background-color: #7366ff; color: #fff; display: inline-block; border-radius: 4px">
            Reset Password
        </a>
    </p>
    <p>If you have remember your password you can safely ignore his email.</p>
    <p>Good luck! Hope it works.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament\resources\views/email/password_reset.blade.php ENDPATH**/ ?>