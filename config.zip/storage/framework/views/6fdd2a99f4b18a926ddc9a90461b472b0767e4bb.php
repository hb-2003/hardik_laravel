 
<?php $__env->startSection('title', 'content'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="main-content">
    <div class="page-content"> 
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-6">
                    <div class="card">
                        <div class="card-body">    
                            <div class="live-preview"> 
                                <form>
                                    <div class="row">
                                        <div class="form-group mb-3">
                                            <select  id="country-dropdown" class="form-control">
                                                <option value="">-- Select Country --</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>">
                                                    <?php echo e($data->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group mb-3">
                                            <select id="state-dropdown" class="form-control">
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <select id="city-dropdown" class="form-control">
                                            </select>
                                        </div>
                                        <!--  <div class="col-lg-12"><br>
                                        <div class="text-end">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                        </div> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  

  
  <?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament1\resources\views/dropdown.blade.php ENDPATH**/ ?>