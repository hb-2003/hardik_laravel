<!doctype html>
<html lang="en" data-layout="twocolumn" data-sidebar="light" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">

<head>

    <meta charset="utf-8" />
    <title>CRM | Velzon - User & Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />

        <title><?php echo e(config('app.name', 'Tournament')); ?> - <?php echo $__env->yieldContent('title'); ?></title>

        <!-- Favicon Icon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('user/images/fav.png')); ?>">

        <!-- Stylesheets -->
        <?php echo $__env->make('layouts.user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <!-- Header Start -->
        <?php echo $__env->make('layouts.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header End -->
        <!-- Body Start -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Body End -->
        <!-- Footer Start -->
        <?php echo $__env->make('layouts.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer End -->
        <!-- Scripts js Start -->
        <?php echo $__env->make('layouts.user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.user.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Scripts js End -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tournament1\resources\views/layouts/user/app.blade.php ENDPATH**/ ?>