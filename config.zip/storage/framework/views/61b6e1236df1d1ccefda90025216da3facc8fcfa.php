
<?php $__env->startSection('title', 'Email Setting'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard'); ?>
<div class="setting-form">
    <div class="user-data full-width">
        <div class="about-left-heading">
            <h3>Email Setting</h3>
        </div>
        <div class="prsnl-info">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <form method="POST" action="<?php echo e(route('user.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Old Email Address*</label>
                            <input class="payment-input" name="old_email" required type="email" placeholder="Enter Old Email Address">
                        </div>
                        <div class="form-group">
                            <label>New Email Address*</label>
                            <input class="payment-input" name="email" required type="email" placeholder="Enter New Email Address">
                        </div>
                        <div class="add-profile-btn">
                            <button class="setting-save-btn" type="submit">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.dashboard.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament1\resources\views/user/dashboard/email.blade.php ENDPATH**/ ?>