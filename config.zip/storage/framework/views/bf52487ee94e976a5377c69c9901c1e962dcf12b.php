

<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('content'); ?>
<div class="error-wrapper">
    <div class="container">
        <img class="img-100" src="<?php echo e(asset('admin/images/other-images/sad.png')); ?>" alt="logo">
        <div class="error-heading">
            <h2 class="headline font-danger">
                404
            </h2>
        </div>
        <div class="col-md-8 offset-md-2">
            <p class="sub-content">
                <?php echo e(__('Not Found')); ?>

            </p>
        </div>
        <div>
            <a class="btn btn-danger-gradien btn-lg" href="<?php echo e(app('router')->has('home') ? route('home') : url('/')); ?>">
                BACK TO HOME PAGE
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament1\resources\views/errors/404.blade.php ENDPATH**/ ?>