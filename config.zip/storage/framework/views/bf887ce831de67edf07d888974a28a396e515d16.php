
<?php $__env->startSection('title', 'Verify Email'); ?>
<?php $__env->startSection('content'); ?>
    <p>Please click the button below to verify your email address.</p>
    <p style="text-align: center">
        <a href="<?php echo e($url); ?>" style="padding: 10px; background-color: #7366ff; color: #fff; display: inline-block; border-radius: 4px">
            Verify Email
        </a>
    </p>
    <p>If you did not create an account, no further action is required.</p>
    <p>Good luck! Hope it works.</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('email.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament\resources\views/email/email_verification.blade.php ENDPATH**/ ?>