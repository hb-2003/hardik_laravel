


<?php $__env->startSection('content'); ?>

<div id="mytask-layout" class="theme-indigo">

    <!-- main body area -->
    <div class="main p-2 py-3 p-xl-5">
        
        <!-- Body: Body -->
        <div class="body d-flex p-0 p-xl-5">
            <div class="container-xxl">

                <div class="row g-0">
                    <div class="col-lg-6 d-none d-lg-flex justify-content-center align-items-center rounded-lg auth-h100">
                        <div style="max-width: 25rem;">
                            <div class="text-center mb-5">
                                 <svg  width="4rem" fill="currentColor" class="bi bi-clipboard-check" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                                    <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
                                    <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
                                </svg>
                            </div>
                            <div class="mb-5">
                                <h2 class="color-900 text-center">My-Task Let's Management Better</h2>
                            </div>
                            <!-- Image block -->
                            <div class="">
                                <img src="<?php echo e(asset('assets/images/login-img.svg')); ?>" alt="login-img">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 d-flex justify-content-center align-items-center border-0 rounded-lg auth-h100">
                        <div class="w-100 p-3 p-md-5 card border-0 bg-dark text-light" style="max-width: 32rem;">
                            <!-- Form -->
                            <form class="row g-1 p-3 p-md-4" action="<?php echo e(route('register')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>

                                <div class="col-12 text-center mb-1 mb-lg-5">
                                    <h1>Create your account</h1>
                                    <span>Free access to our dashboard.</span>
                                </div>
                                <div class="col-6">
                                    <div class="mb-2">
                                        <label class="form-label">Full name</label>
                                        <input id="first_name" class="form-control form-control-lg" type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" placeholder="First Name" autofocus required >
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-2">
                                        <label class="form-label">&nbsp;</label>
                                        <input id="last_name" class="form-control form-control-lg" type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Last Name" autofocus required >
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-2">
                                        <label class="form-label">Email address</label>
                                         <input type="email" class="form-control form-control-lg" id="email" placeholder="Enter email address"  name="email" value="<?php echo e(old('email')); ?>"  autofocus required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-lg" id="user_name" placeholder="Enter username" name="user_name" value="<?php echo e(old('user_name')); ?>" autofocus required>
                                </div>
                                       
                                <div class="col-12">
                                    <div class="mb-2">
                                        <label class="form-label">Password</label>
                                     <!--    <input type="password" id="password"  name="password" class="form-control form-control-lg" placeholder="8+ characters required"> -->

                                      <input type="password" class="form-control form-control-lg" onpaste="return false" placeholder="Enter password" id="password"  name="password" required>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-2">
                                        <label class="form-label">Confirm password</label>
                                        <!-- <input type="password" name="password_confirmation" id="password_confirmation" class="form-control form-control-lg" placeholder="8+ characters required"> -->
                                          <input id="password_confirmation" class="form-control form-control-lg" type="password" name="password_confirmation" placeholder="Confirm Password" required >
                                    </div>
                                </div>
                                 <label class="form-label" for="password-input">referralcode</label>

                                <input id="referralcode" class="form-control form-control-lg" type="text" value="<?php if(isset($_GET['referralcode'])): ?>
                                                    <?php echo e($_GET['referralcode']); ?>

                                                                <?php endif; ?>
                                            " required readonly>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            I accept the <a href="#" title="Terms and Conditions" class="text-secondary">Terms and Conditions</a>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12 text-center mt-4">
                                    <!-- <a href="auth-signin.html" class="btn btn-lg btn-block btn-light lift text-uppercase" alt="SIGNUP">SIGN UP</a> -->
                               
                                <button class="btn btn-lg btn-block btn-light lift text-uppercase" type="submit">SIGN UP</button>
                                 </div>
                                <div class="col-12 text-center mt-4">
                                    <span class="text-muted">Already have an account? <a href="<?php echo e(route('login')); ?>" title="Sign in" class="text-secondary">Sign in here</a></span>
                                </div>
                            </form>
                            <!-- End Form -->
                        </div>
                    </div>
                </div> <!-- End Row -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament\resources\views/auth/register.blade.php ENDPATH**/ ?>