
<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard'); ?>
<div class="setting-form">
    <div class="user-data full-width">
        <div class="about-left-heading">
            <h3>Profile</h3>
        </div>
        <div class="prsnl-info">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <form method="POST" action="<?php echo e(route('user.profile')); ?>" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Avatar*</label>
                            <div class="setting-dp">
                                <img src="<?php echo e(Auth::user()->image()); ?>?w=150&h=150" alt="logo">
                            </div>
                            <div class="setting-upload">
                                <span>Upload a new avatar.</span>
                                <div class="addpic" id="images">
                                    <input type="file" id="file2" name="images" >
                                    <label for="file2">Choose File</label>
                                    <p>JPEG / PNG 150x150*</p>
                                </div>
                            </div>

                        </div>
                        <div class="form-group">
                            <label>Background*</label>
                            <div class="setting-bg">
                                <img src="<?php echo e(Auth::user()->background()); ?>?w=810&h=270" alt="logo">
                            </div>
                            <div class="setting-upload">
                                <span>Upload a new background.</span>
                                <div class="addpic" id="backgrounds">
                                    <input type="file" id="file" name="backgrounds" >
                                    <label for="file">Choose File</label>
                                    <p>JPEG / PNG 150x150*</p>
                                </div>
                            </div>
                        </div>
                        <div class="add-profile-btn">
                            <button class="setting-save-btn" type="submit">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.dashboard.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tournament1\resources\views/user/dashboard/profile.blade.php ENDPATH**/ ?>